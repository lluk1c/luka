namespace pucac
{
    public partial class Form1 : Form
    {
        int pom = 12;
        int pravac = 555;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            timer3.Start();
            button4.Focus();
            label2.Text = "0";
            button4.Top = 352;
            button4.Left = 202;
            button2.Top = 39;
            button2.Left = 73;
            button3.Top = 39;
            button3.Left = 296;
            button5.Top = 999;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pravac == 0) button4.Left += pom;
            if (pravac == 2) button4.Left -= pom;

            if (button4.Left > 539) button4.Left = 0;
            if (button4.Left < 0) button4.Left = 539;
        }

        private void button4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') pravac = 2;
            if (e.KeyChar == 'd') pravac = 0;
            if (e.KeyChar == ' ')
            {

                button5.Left = button4.Left + 10;
                button5.Top = button4.Top + 10;

                timer2.Start();


            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button5.Top -= 20;
            int poeni = Convert.ToInt32(label2.Text);
            if (button5.Bounds.IntersectsWith(button3.Bounds))
            {
                Random x = new Random();
                int br = x.Next(0, 7);
                poeni++;
                button3.Top = 0;
                button3.Left = br * 72;
            }
            if (button5.Bounds.IntersectsWith(button2.Bounds))
            {
                Random y = new Random();
                int br1 = y.Next(0, 7);
                poeni++;
                button2.Top = 0;
                button2.Left = br1 * 72;
            }

            label2.Text = Convert.ToString(poeni);
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            button3.Top += 3;
            button2.Top += 3;
            if (button2.Top > 373 || button3.Top > 373)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                MessageBox.Show("GOTOVO!!!");
            }

            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                MessageBox.Show("GOTOVO!!!");
            }

            if (button3.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                MessageBox.Show("GOTOVO!!!");
            }
        }
    }
}