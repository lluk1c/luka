namespace lavirint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "50";
            timer1.Start();
            timer2.Start();
            button1.Focus();
            button2.Left = 12;
            button2.Top = 35;
            

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button11.Left += 5;
            if (button11.Top > 708) button11.Top = 480;

            button12.Top += 5;
            if (button12.Top > 708) button12.Top = 368;

            button13.Top -= 5;
            if (button13.Top < 402) button13.Top = 710;
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button1.Left -= 10;
            if (e.KeyChar == 's') button1.Top += 10;
            if (e.KeyChar == 'd') button1.Left += 10;
            if (e.KeyChar == 'w') button1.Top -= 10;

            if (button1.Left < 0) button1.Left = 10;
            if (button1.Left > 1339) button1.Left = 1327;
            if (button1.Top < 0) button1.Top = 12;
            if (button1.Top > 708) button1.Top = 696;

            if (button2.Bounds.IntersectsWith(button2.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button8.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button9.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button10.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button11.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button12.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button13.Bounds))
            {
                button2.Left = 12;
                button2.Top = 35;
            }
            if (button2.Bounds.IntersectsWith(button14.Bounds))
            {
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("THE END");
            
            }
        }

            
    }
}
